"""
AI Baseplate — RAG (Retrieval-Augmented Generation) Template
Ask questions about your own documents using Gemini + ChromaDB.
"""

import os
from dotenv import load_dotenv
from core.llm import get_llm
import chromadb
from chromadb.utils import embedding_functions

load_dotenv()

# Setup ChromaDB with Gemini embeddings
client = chromadb.Client()
gemini_ef = embedding_functions.GoogleGenerativeAiEmbeddingFunction(
    api_key=os.getenv("GEMINI_API_KEY")
)
collection = client.get_or_create_collection(
    name="documents",
    embedding_function=gemini_ef
)

llm = get_llm("gemini")


def ingest(docs: list[str], ids: list[str]):
    """Add documents to the vector store."""
    collection.add(documents=docs, ids=ids)
    print(f"✅ Ingested {len(docs)} document(s).")


def query(question: str, n_results: int = 3) -> str:
    """Retrieve relevant docs and answer the question."""
    results = collection.query(query_texts=[question], n_results=n_results)
    context = "\n\n".join(results["documents"][0])

    prompt = f"""Answer the question using ONLY the context below.
If the answer isn't in the context, say "I don't know."

Context:
{context}

Question: {question}
Answer:"""

    return llm.ask(prompt)


if __name__ == "__main__":
    # Demo: ingest sample docs and query
    sample_docs = [
        "AI Baseplate is an open-source starter kit for building AI applications.",
        "It supports Google Gemini as an LLM provider.",
        "RAG stands for Retrieval-Augmented Generation — it grounds LLMs in your data.",
    ]
    ingest(sample_docs, ids=["doc1", "doc2", "doc3"])

    print("\n📚 RAG App ready. Ask questions about your documents.\n")
    while True:
        q = input("Question: ").strip()
        if q.lower() in ("exit", "quit"):
            break
        answer = query(q)
        print(f"\nAnswer: {answer}\n")
