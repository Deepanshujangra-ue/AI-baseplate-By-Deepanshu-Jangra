"""
AI Baseplate — Chatbot Template
A simple conversational chatbot powered by Google Gemini.
"""

from core.agents.base_agent import BaseAgent
from dotenv import load_dotenv

load_dotenv()

if __name__ == "__main__":
    agent = BaseAgent(
        provider="gemini",
        system_prompt="You are a friendly and helpful assistant. Be concise and clear."
    )
    agent.run()
