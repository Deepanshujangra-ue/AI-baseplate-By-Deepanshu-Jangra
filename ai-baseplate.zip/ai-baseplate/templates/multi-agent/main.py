"""
AI Baseplate — Multi-Agent Template
Multiple specialized agents collaborating to solve a task.
"""

from core.agents.base_agent import BaseAgent
from dotenv import load_dotenv

load_dotenv()


class ResearcherAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            system_prompt="You are a research specialist. Given a topic, provide detailed factual information, key points, and relevant context."
        )


class WriterAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            system_prompt="You are a professional writer. Given research notes, write a clear, engaging, and well-structured summary for a general audience."
        )


class CriticAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            system_prompt="You are a critical reviewer. Given a written piece, identify weaknesses, suggest improvements, and rate it out of 10."
        )


def run_pipeline(topic: str):
    print(f"\n🚀 Running multi-agent pipeline on: '{topic}'\n")

    researcher = ResearcherAgent()
    writer = WriterAgent()
    critic = CriticAgent()

    print("🔍 Researcher is working...")
    research = researcher.think(f"Research this topic thoroughly: {topic}")
    print(f"\nResearch:\n{research}\n")

    print("✍️  Writer is working...")
    article = writer.think(f"Write a summary based on this research:\n{research}")
    print(f"\nArticle:\n{article}\n")

    print("🧐 Critic is reviewing...")
    review = critic.think(f"Review this article:\n{article}")
    print(f"\nReview:\n{review}\n")


if __name__ == "__main__":
    topic = input("Enter a topic for the multi-agent pipeline: ").strip()
    run_pipeline(topic)
