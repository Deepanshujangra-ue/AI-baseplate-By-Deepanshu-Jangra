# Contributing to AI Baseplate

Thanks for wanting to contribute! Here's how.

## Adding a Template

1. Fork the repo
2. Create `templates/your-template-name/main.py`
3. Keep it self-contained — only import from `core/`
4. Add a short `README.md` in your template folder
5. Open a PR

## Adding a Provider

1. Create `core/llm/your_provider.py` — implement `ask()`, `start_chat()`, `send()`, `reset()`
2. Register it in `core/llm/__init__.py`
3. Open a PR

## Rules

- No external dependencies beyond what's in `requirements.txt` unless necessary
- Keep templates simple — they're starting points, not full apps
- Document your env vars in `.env.example`
