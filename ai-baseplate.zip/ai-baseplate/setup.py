from setuptools import setup, find_packages

setup(
    name="ai-baseplate",
    version="0.1.0",
    description="Open-source AI starter kit — scaffold AI apps in seconds",
    packages=find_packages(),
    install_requires=[
        "google-generativeai>=0.5.0",
        "chromadb>=0.4.0",
        "python-dotenv>=1.0.0",
        "click>=8.1.0",
    ],
    entry_points={
        "console_scripts": [
            "ai-baseplate=cli.main:cli",
        ],
    },
    python_requires=">=3.10",
)
