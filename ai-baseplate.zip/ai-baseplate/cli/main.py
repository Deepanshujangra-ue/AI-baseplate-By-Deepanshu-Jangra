#!/usr/bin/env python3
"""
AI Baseplate CLI
Usage:
  ai-baseplate init <project-name>
  ai-baseplate add <template>
"""

import click
import os
import shutil
from pathlib import Path

TEMPLATES = ["chatbot", "rag-app", "multi-agent"]
BASEPLATE_DIR = Path(__file__).parent.parent  # root of ai-baseplate


def copy_core(dest: Path):
    """Copy core/ into the destination project."""
    src_core = BASEPLATE_DIR / "core"
    dest_core = dest / "core"
    if src_core.exists():
        shutil.copytree(src_core, dest_core, dirs_exist_ok=True)


def write_env(dest: Path):
    env_content = "GEMINI_API_KEY=your_gemini_api_key_here\n"
    (dest / ".env.example").write_text(env_content)
    click.echo("  📄 Created .env.example")


def write_requirements(dest: Path):
    reqs = (
        "google-generativeai>=0.5.0\n"
        "chromadb>=0.4.0\n"
        "python-dotenv>=1.0.0\n"
        "click>=8.1.0\n"
    )
    (dest / "requirements.txt").write_text(reqs)
    click.echo("  📄 Created requirements.txt")


def write_gitignore(dest: Path):
    content = ".env\n__pycache__/\n*.pyc\n.venv/\n"
    (dest / ".gitignore").write_text(content)
    click.echo("  📄 Created .gitignore")


def write_readme(dest: Path, project_name: str, template: str):
    content = f"""# {project_name}

Built with [AI Baseplate](https://github.com/your-org/ai-baseplate) — Template: `{template}`

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Add your GEMINI_API_KEY to .env
python main.py
```

## Structure

```
{project_name}/
├── core/           # AI Baseplate core (LLM, agents, tools)
├── main.py         # Entry point
├── .env.example    # Environment variables template
└── requirements.txt
```
"""
    (dest / "README.md").write_text(content)
    click.echo("  📄 Created README.md")


@click.group()
def cli():
    """🤖 AI Baseplate — Open-source AI starter kit"""
    pass


@cli.command()
@click.argument("project_name")
@click.option("--template", "-t", default="chatbot",
              type=click.Choice(TEMPLATES), show_default=True,
              help="Template to scaffold")
def init(project_name, template):
    """Scaffold a new AI project."""
    dest = Path.cwd() / project_name

    if dest.exists():
        click.echo(f"❌ Directory '{project_name}' already exists.")
        raise SystemExit(1)

    click.echo(f"\n🚀 Creating project '{project_name}' with template '{template}'...\n")
    dest.mkdir(parents=True)

    # Copy template main.py
    src_template = BASEPLATE_DIR / "templates" / template / "main.py"
    if src_template.exists():
        shutil.copy(src_template, dest / "main.py")
        click.echo(f"  📄 Copied {template} template")

    # Copy core
    copy_core(dest)
    click.echo("  📦 Copied core engine")

    # Boilerplate files
    write_env(dest)
    write_requirements(dest)
    write_gitignore(dest)
    write_readme(dest, project_name, template)

    click.echo(f"""
✅ Project ready!

  cd {project_name}
  pip install -r requirements.txt
  cp .env.example .env   # then add your GEMINI_API_KEY
  python main.py
""")


@cli.command()
@click.argument("template", type=click.Choice(TEMPLATES))
def add(template):
    """Add a template to the current project."""
    dest = Path.cwd()

    if not (dest / "core").exists():
        click.echo("❌ No AI Baseplate core found in this directory.")
        click.echo("   Run `ai-baseplate init <project>` first, or run this from your project root.")
        raise SystemExit(1)

    src_template = BASEPLATE_DIR / "templates" / template / "main.py"
    out_file = dest / f"{template.replace('-', '_')}.py"

    if out_file.exists():
        click.echo(f"⚠️  {out_file.name} already exists. Skipping.")
    else:
        shutil.copy(src_template, out_file)
        click.echo(f"✅ Added template '{template}' → {out_file.name}")

    click.echo(f"\nRun it with: python {out_file.name}\n")


@cli.command()
def list():
    """List available templates."""
    click.echo("\n📦 Available templates:\n")
    descriptions = {
        "chatbot":     "A conversational AI chatbot with multi-turn memory",
        "rag-app":     "Ask questions over your own documents (RAG)",
        "multi-agent": "Multiple specialized agents working in a pipeline",
    }
    for t in TEMPLATES:
        click.echo(f"  {t:<15} {descriptions[t]}")
    click.echo()


if __name__ == "__main__":
    cli()
