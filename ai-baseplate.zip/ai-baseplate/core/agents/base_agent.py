"""
Base Agent — the core reasoning loop for AI Baseplate.
Extend this class to build custom agents.
"""

from core.llm import get_llm
from typing import Optional


class BaseAgent:
    def __init__(self, provider: str = "gemini", system_prompt: Optional[str] = None, **llm_kwargs):
        self.llm = get_llm(provider, **llm_kwargs)
        self.system_prompt = system_prompt or "You are a helpful AI assistant."
        self.memory = []  # simple in-memory history
        self.llm.start_chat()

    def think(self, user_input: str) -> str:
        """Process input and return a response."""
        self.memory.append({"role": "user", "content": user_input})
        full_prompt = f"{self.system_prompt}\n\nUser: {user_input}"
        response = self.llm.send(full_prompt)
        self.memory.append({"role": "assistant", "content": response})
        return response

    def reset(self):
        """Clear memory and restart."""
        self.memory = []
        self.llm.reset()
        self.llm.start_chat()

    def run(self):
        """Interactive CLI loop."""
        print(f"\n🤖 Agent ready. Type 'exit' to quit.\n")
        while True:
            user_input = input("You: ").strip()
            if user_input.lower() in ("exit", "quit"):
                print("Goodbye!")
                break
            if not user_input:
                continue
            response = self.think(user_input)
            print(f"\nAgent: {response}\n")
