from .gemini import GeminiLLM

def get_llm(provider: str = "gemini", **kwargs):
    if provider == "gemini":
        return GeminiLLM(**kwargs)
    raise ValueError(f"Unsupported provider: {provider}. Supported: ['gemini']")
