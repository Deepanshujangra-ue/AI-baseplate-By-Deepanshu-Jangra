"""
Google Gemini LLM connector for AI Baseplate.
"""

import os
from typing import Optional
import google.generativeai as genai


class GeminiLLM:
    def __init__(self, model: str = "gemini-1.5-flash", api_key: Optional[str] = None):
        self.model_name = model
        api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not set. Add it to your .env file.")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model)
        self.chat = None

    def ask(self, prompt: str) -> str:
        """Single-turn completion."""
        response = self.model.generate_content(prompt)
        return response.text

    def start_chat(self):
        """Start a multi-turn chat session."""
        self.chat = self.model.start_chat(history=[])
        return self

    def send(self, message: str) -> str:
        """Send a message in an ongoing chat session."""
        if not self.chat:
            self.start_chat()
        response = self.chat.send_message(message)
        return response.text

    def reset(self):
        """Reset chat history."""
        self.chat = None
